CN = float(input("Nhập cân nặng(kg):"))
CC = float(input("Nhập chiều cao(m):"))
BMI = CN / (CC ** 2)
print(f"Chỉ số BMI của bạn là:  {BMI:.2f}")
if BMI < 18.5:
   print("Gầy")
elif BMI >= 18.5 and BMI <= 24.9:
     print("Bình thường")
elif BMI >= 25 and BMI <= 29.9:
    print("Thừa cân")
else:
    print("Béo phì")

