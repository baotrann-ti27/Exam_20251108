N= int(input(" Nhập tuổi: "))
if N < 12:
    print("Trẻ em")
elif 12 <= N <= 17:
     print("Thiếu niên")
elif 18 <= N <= 59:
     print("Người trưởng thành")
else:
    print("Người cao tuổi")
