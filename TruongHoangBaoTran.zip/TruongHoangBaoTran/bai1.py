N= int(input("Nhập số nguyên N: "))
if N > 0:
    print( " N là số dương")
elif N < 0:
    print(" N là số âm")
else:
    print("N là số 0")


