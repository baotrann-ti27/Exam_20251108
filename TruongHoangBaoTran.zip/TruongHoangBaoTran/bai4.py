diem = float(input("Nhập điểm số học sinh: "))
if 8.5 <= diem <= 10:
    print("Xếp hạng A")
elif 7 <= diem < 8.5:
     print("Xếp hạng B")
elif 5 <= diem <7:
     print("Xếp hạng C")
else:
    print("Xếp hạng D")
