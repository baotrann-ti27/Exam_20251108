N= int(input(" Nhập số kwh điện đã sử dụng trong tháng: "))
if N <= 100:
    tien = N * 2000
elif N <= 200:
     tien + 100 * 2000 + (N -  100) * 3000
else:
     tien + 100 * 2000 + 100 * 3000 + (N - 200) * 4000
print(" Tiền điện phải trả là: " , tien, "đồng")